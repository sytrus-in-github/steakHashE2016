package firstRound;

public class Simulation {
	
	Warehouse[] warehouses;
	Order[] orders;
	
	public Simulation() {
		for (int i = 0; i < Q.W; i++) {
				
		}
	}

}
