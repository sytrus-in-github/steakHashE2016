package firstRound;

import java.util.ArrayList;

public class Yuesong {
	
	public boolean isUseful(Order o, Warehouse w){
		for(int i:o.items.keySet()){
			
		}
	}
	public int findNearestUsefulWarehouse(Order o){
		
	}
	
	public int alwaysNearest(Order i, ArrayList<Integer> warehouses){
		
	}
}
