package tools;

public class Algorithm implements Runnable {

	public float score = 0;
	public int rank = -1;
	public boolean performed = false;
	@Override
	public void run() {
		//remenber to set the score value according to the running result
	}

}
