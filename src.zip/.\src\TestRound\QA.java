package TestRound;

public class QA {
	int hi = 1;
	int hihi = 2;
	int hihihi = 3;
	int hihsiad = 34;
}
